class Node {
  constructor(stop) {
    this.stop = stop;
    this.next = null;
  }
}

class LinkedList {
  constructor() {
    this.head = null;
    this.currentIndex = -1;
  }

  fromArray(arr) {
    this.head = null;
    let tail = null;
    arr.forEach(s => {
      const n = new Node(s);
      if (!this.head) { this.head = n; tail = n; }
      else { tail.next = n; tail = n; }
    });
  }

  toArray() {
    const res = [];
    let t = this.head;
    while (t) { res.push(t.stop); t = t.next; }
    return res;
  }

  add(stop) {
    const n = new Node(stop);
    if (!this.head) this.head = n;
    else {
      let t = this.head;
      while (t.next) t = t.next;
      t.next = n;
    }
    this.save();
  }

  delete(stop) {
    if (!this.head) return false;
    if (this.head.stop.toLowerCase() === stop.toLowerCase()) {
      this.head = this.head.next;
      this.save();
      return true;
    }
    let t = this.head;
    while (t.next && t.next.stop.toLowerCase() !== stop.toLowerCase()) t = t.next;
    if (t.next) {
      t.next = t.next.next;
      this.save();
      return true;
    }
    return false;
  }

  search(stop) {
    let t = this.head;
    let index = 1;
    while (t) {
      if (t.stop.toLowerCase() === stop.toLowerCase()) return index;
      t = t.next;
      index++;
    }
    return -1;
  }

  next() {
    const arr = this.toArray();
    if (!arr.length) return null;
    if (this.currentIndex < arr.length - 1) {
      this.currentIndex++;
      this.save();
      return arr[this.currentIndex];
    } else {
      this.currentIndex = -1;
      this.save();
      return null;
    }
  }

  reset() {
    this.currentIndex = -1;
    this.save();
  }

  save() {
    const data = { stops: this.toArray(), currentIndex: this.currentIndex };
    localStorage.setItem('travel_list', JSON.stringify(data));
  }

  load() {
    const raw = localStorage.getItem('travel_list');
    if (!raw) return;
    const data = JSON.parse(raw);
    this.fromArray(data.stops || []);
    this.currentIndex = data.currentIndex || -1;
  }
}

const LIST = new LinkedList();
LIST.load();

/* ---------- Page logic ---------- */
function renderSnapshot() {
  const el = document.getElementById('snapshotText');
  if (!el) return;
  const stops = LIST.toArray();
  el.textContent = stops.length ? stops.join(' → ') : 'No stops yet.';
}

/* Add Stop page */
function initAddStop() {
  const btn = document.getElementById('addBtn');
  const input = document.getElementById('stopName');
  const msg = document.getElementById('message');
  if (!btn) return;
  btn.addEventListener('click', () => {
    const val = input.value.trim();
    if (!val) { msg.textContent = "Please enter a destination!"; return; }
    LIST.add(val);
    msg.textContent = `✅ Added: ${val}`;
    input.value = '';
    renderSnapshot();
  });
}

/* Destinations page */
function renderStops() {
  const ul = document.getElementById('stopList');
  if (!ul) return;
  ul.innerHTML = '';
  const stops = LIST.toArray();
  if (!stops.length) { ul.innerHTML = "<li class='muted'>No destinations added yet.</li>"; return; }
  stops.forEach((s, i) => {
    const li = document.createElement('li');
    li.innerHTML = `${i + 1}. ${s}`;
    ul.appendChild(li);
  });
}

function initDeleteControl() {
  const delBtn = document.getElementById('delBtn');
  const delInput = document.getElementById('deleteName');
  if (!delBtn) return;
  delBtn.addEventListener('click', () => {
    const name = delInput.value.trim();
    if (!name) return alert("Enter a destination name!");
    const result = LIST.delete(name);
    alert(result ? "Deleted successfully!" : "Destination not found.");
    renderStops();
  });
}

function searchStop() {
  const name = document.getElementById('searchName').value.trim();
  if (!name) return alert("Enter destination to search.");
  const index = LIST.search(name);
  alert(index !== -1 ? `Found "${name}" at position ${index}` : "Not found.");
}

/* Next Stop page */
function initNextControls() {
  const nextBtn = document.getElementById('nextBtn');
  const resetBtn = document.getElementById('resetBtn');
  const curr = document.getElementById('currentStop');
  if (!nextBtn) return;

  nextBtn.addEventListener('click', () => {
    const next = LIST.next();
    curr.textContent = next ? `Next Stop ➡️ ${next}` : "🎉 End of itinerary!";
  });
  resetBtn.addEventListener('click', () => {
    LIST.reset();
    curr.textContent = "Traversal reset — press Next Stop to start again.";
  });
}
/* ---------- Trip Tools Page ---------- */
function initTripTools() {
  const startDate = document.getElementById("startDate");
  const endDate = document.getElementById("endDate");
  const transport = document.getElementById("transport");
  const budget = document.getElementById("budget");
  const saveBtn = document.getElementById("saveTrip");
  const reminderBox = document.getElementById("reminderBox");
  if (!saveBtn) return;

  const saved = JSON.parse(localStorage.getItem("trip_tools")) || null;
  if (saved) {
    startDate.value = saved.startDate || "";
    endDate.value = saved.endDate || "";
    transport.value = saved.transport || "";
    budget.value = saved.budget || "";
    updateReminder(saved, reminderBox);
  }

  saveBtn.addEventListener("click", () => {
    const data = {
      startDate: startDate.value,
      endDate: endDate.value,
      transport: transport.value,
      budget: budget.value
    };
    localStorage.setItem("trip_tools", JSON.stringify(data));
    updateReminder(data, reminderBox);
    alert("✅ Trip details saved successfully!");
  });
}

function updateReminder(data, box) {
  if (!data.startDate) {
    box.innerHTML = "No trip planned yet.";
    return;
  }
  const today = new Date();
  const start = new Date(data.startDate);
  const diffDays = Math.ceil((start - today) / (1000 * 60 * 60 * 24));
  if (diffDays > 0) {
    box.innerHTML = `📅 Your trip starts in <b>${diffDays}</b> day(s)!<br>
    🚗 Mode: ${data.transport || "Not set"}<br>
    💰 Budget: $${data.budget || "N/A"}<br>
    📍 From: ${data.startDate} to ${data.endDate}`;
  } else {
    box.innerHTML = `🌄 Trip is ongoing or completed!<br>
    📍 From: ${data.startDate} to ${data.endDate}`;
  }
}

/* Initialize trip tools when needed */
window.addEventListener("DOMContentLoaded", () => {
  initTripTools();
});




/* Initialize on DOM load */
window.addEventListener('DOMContentLoaded', () => {
  renderSnapshot();
  initAddStop();
  renderStops();
  initDeleteControl();
  initNextControls();
});